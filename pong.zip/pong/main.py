import pygame
from numpy import array
from sys import exit
from random import choice

class Game:
    def __init__(self):
        # init
        pygame.init()

        # general
        self.screen = pygame.display.set_mode((800, 600))
        self.clock = pygame.time.Clock()
        pygame.display.set_caption("Pong")

        # Text
        self.font = pygame.font.Font("assets/font.TTF", 36)
        self.big_font = pygame.font.Font("assets/font.TTF", 72)

        self.instructions1 = self.font.render("press  space  to  play", False, "#ffffff")
        self.instructions2 = self.font.render("press  enter  to  change  robot  setting", False, "#ffffff")
        self.instructions3 = self.font.render("use  arrow  keys  to  change  speed", False, "#ffffff")
        self.player1win = self.big_font.render("Player 1 wins!", False, (255, 0, 0))
        self.player2win = self.big_font.render("Player 2 wins!", False, (0, 0, 255))
        self.ai_on = self.font.render("Robot ON", False, (255, 255, 255))
        self.ai_off = self.font.render("Robot OFF", False, (255, 255, 255))

        self.player1win_rec = self.player1win.get_rect(center=(400, 160))
        self.player2win_rec = self.player2win.get_rect(center=(400, 160))

        # Positions
        self.p1_pos = array([10, 250])
        self.p2_pos = array([760, 250])
        self.ball_pos = array([385, 285])

        # Speed
        self.ball_accelaration = array([10, 1])
        self.player_accelaration = array([0, 10])

        # load images
        self.background = pygame.image.load("assets/background.jpg").convert_alpha()
        self.player1 = pygame.image.load("assets/red.png").convert_alpha()
        self.player2 = pygame.image.load("assets/blue.png").convert_alpha()
        self.ball = pygame.image.load("assets/ball.png").convert_alpha()
        self.manni = pygame.image.load("assets/manni.png").convert_alpha()

        self.manni_rec = self.manni.get_rect(center=(400, 370))
        self.player_rec = self.player1.get_rect(x=self.p1_pos[0], y=self.p1_pos[1], w=10, h=100)
        self.player2_rec = self.player2.get_rect(x=self.p2_pos[0], y=self.p2_pos[1], w=10, h=100)

        # Variabels
        self.ball_rec = None
        self.speed = None
        self.winner = None

        self.playing = False
        self.ai = True

        # Game loop
        self.gameover_screen()
        self.game_loop()

    def reset(self):
        self.p1_pos = array([10, 250])
        self.p2_pos = array([760, 250])
        self.ball_pos = array([385, 285])
        self.ball_accelaration[1] = 1

    def gameover_screen(self):
        self.screen.blit(self.instructions1, (100, 20))
        self.screen.blit(self.instructions2, (100, 50))
        self.screen.blit(self.instructions3, (100, 80))
        speed_string = "Speed 10"
        if self.ball_rec is not None:
            if self.ball_rec.x > 400:
                self.winner = 1
                self.screen.blit(self.player1win, self.player1win_rec)
                speed_string = "Speed " + str(self.ball_accelaration[0])
            else:
                self.winner = 2
                self.screen.blit(self.player2win, self.player2win_rec)
                speed_string = "Speed " + str(self.ball_accelaration[0] * -1)
        self.screen.blit(self.manni, self.manni_rec)

        self.screen.blit(
            self.font.render(speed_string, False, (255, 255, 255)), (400, 550))
        if self.ai:
            self.screen.blit(self.ai_on, (200, 550))
        else:
            self.screen.blit(self.ai_off, (200, 550))

    def game_loop(self):
        while True:
            self.clock.tick(60)


            self.check_for_input()

            if self.playing:
                self.screen.blit(self.background, (0, 0))
                self.update_items()
                self.draw_to_screen()

            else:
                self.screen.fill("#000000")
                self.gameover_screen()

            # update
            pygame.display.flip()

    def check_for_input(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            elif not self.playing:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        self.playing = True
                        self.reset()

                    elif self.winner == 1:
                        if event.key == pygame.K_UP and self.ball_accelaration[0] < 25:
                            self.ball_accelaration += array([1, 0])
                        elif event.key == pygame.K_DOWN and self.ball_accelaration[0] > 1:
                            self.ball_accelaration -= array([1, 0])
                    else:
                        if event.key == pygame.K_UP and self.ball_accelaration[0] * -1 < 25:
                            self.ball_accelaration -= array([1, 0])
                        elif event.key == pygame.K_DOWN and self.ball_accelaration[0] * -1 > 1:
                            self.ball_accelaration += array([1, 0])

                    if event.key == pygame.K_RETURN:
                        self.ai = not self.ai

        if self.ai:
            if self.ball_pos[0] < 400 and self.ball_accelaration[0] < 0:
                if self.p1_pos[1] <= self.ball_pos[1] - 25:
                    self.p1_pos[1] += 10
                else:
                    self.p1_pos[1] -= 10

        else:
            if pygame.key.get_pressed()[pygame.K_w]:
                self.p1_pos += self.player_accelaration * array([0, -1])

            if pygame.key.get_pressed()[pygame.K_s]:
                self.p1_pos += self.player_accelaration

        if pygame.key.get_pressed()[pygame.K_UP]:
            self.p2_pos += self.player_accelaration * array([0, -1])

        if pygame.key.get_pressed()[pygame.K_DOWN]:
            self.p2_pos += self.player_accelaration

    def update_items(self):
        if self.ball_collision_screen_left() or self.ball_collision_screen_right():
            self.playing = False

        if self.ball_player_collision():
            self.ball_accelaration *= array([-1, 1])
            self.ball_accelaration += array([0, choice([1, -1, -2, 1])])

        if self.ball_collision_screen_top() or self.ball_collision_screen_bottom():
            self.ball_accelaration *= array([1, -1])

        self.ball_pos += self.ball_accelaration

    def draw_to_screen(self):
        self.ball_rec = self.ball.get_rect(x=self.ball_pos[0], y=self.ball_pos[1], w=15, h=15)
        self.screen.blit(self.player1, self.player1.get_rect(x=self.p1_pos[0], y=self.p1_pos[1], w=10, h=100))
        self.screen.blit(self.player2, self.player2.get_rect(x=self.p2_pos[0], y=self.p2_pos[1], w=10, h=100))
        self.screen.blit(self.ball, self.ball_rec)

    def ball_player_collision(self):
        return self.ball_player1_collision() or self.ball_player2_collision()

    def ball_player1_collision(self):
        return self.aabbcollision(self.p1_pos[0], self.p1_pos[1], 10, 100, self.ball_pos[0], self.ball_pos[1], 15, 15)

    def ball_player2_collision(self):
        return self.aabbcollision(self.p2_pos[0], self.p2_pos[1], 10, 100, self.ball_pos[0], self.ball_pos[1], 15, 15)

    @staticmethod
    def aabbcollision(a_x, a_y, a_width, a_height, b_x, b_y, b_width, b_height):
        collision_x = a_x + a_width >= b_x and b_x + b_width - 10 >= a_x
        collision_y = a_y + a_height >= b_y and b_y + b_height >= a_y

        return collision_x and collision_y

    def ball_collision_screen_left(self):
        return self.ball_pos[0] <= 0

    def ball_collision_screen_right(self):
        return self.ball_pos[0] + 15 >= 800

    def ball_collision_screen_top(self):
        return self.ball_pos[1] <= 0

    def ball_collision_screen_bottom(self):
        return self.ball_pos[1] + 15 >= 600

Game()